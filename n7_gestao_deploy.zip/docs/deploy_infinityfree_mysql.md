# N7 Gestão – Guia de Deploy no Hosting com MySQL (InfinityFree)

## Pré-requisitos

- Acesso ao painel da InfinityFree
- Banco MySQL criado: host `sql211.infinityfree.com`, usuário `if0_43338625`
- FTP: host `ftpupload.net`, usuário `if0_43338625`
- Projeto Python Flask com SQLAlchemy (neste repositório)

---

## Passo 1 – Preparação do ambiente local

```bash
pip install -r requirements.txt
```

Edite o arquivo `.env`:

```env
SECRET_KEY=sua_chave_secreta_aqui
DATABASE_URL=mysql+pymysql://if0_43338625:SUA_SENHA@sql211.infinityfree.com:3306/if0_43338625
UPLOAD_DIR=/caminho/para/public_html/uploads
```

---

## Passo 2 – Criar as tabelas no MySQL

Com o `DATABASE_URL` apontando para o MySQL, execute:

```python
from app import create_app
from app.extensions import db

app = create_app()
with app.app_context():
    db.create_all()
```

---

## Passo 3 – Upload via FTP

1. Use FileZilla (ou cliente FTP) com:
   - Host: `ftpupload.net`
   - Usuário: `if0_43338625`
   - Senha: *(definida no painel)*
2. Faça upload da estrutura do projeto para a pasta `public_html` do domínio.

Estrutura mínima recomendada em `public_html`:

```
public_html/
├── wsgi.py
├── run.py
├── requirements.txt
├── .env
├── app/
│   ├── ...
└── instance/
    └── uploads/
```

---

## Passo 4 – Configurar WSGI

Crie/editar o arquivo `wsgi.py` na raiz:

```python
from app import create_app

application = create_app()
```

---

## Passo 5 – Configurar variáveis de ambiente no servidor

No Apache/Passenger (dependendo do painel):

```apache
PassengerEnabled On
PassengerAppRoot /caminho/public_html
PassengerPython /path/to/python
SetEnv PYTHONPATH /caminho/public_html
```

---

## Passo 6 – Testar

1. Acesse `https://<seu-dominio>/auth/primeiro-acesso`
2. Cadastre empresa e administrador
3. Acesse `https://<seu-dominio>/auth/login`

---

## ⚠️ Observações importantes sobre o plano free

- O plano gratuito pode **não suportar WSGI/Python** da forma desejada (muitos hosts gratuitos só hospedam PHP).
- Se o InfinityFree não suportar Python, a solução comercial recomendada é uma **VPS**.
- O `DEBUG=True` **não deve** ser usado em produção.

---

## 🔧 Comandos de manutenção no MySQL

```bash
# Backup
mysqldump -h sql211.infinityfree.com -u if0_43338625 -p if0_43338625 n7_gestao > backup.sql

# Restore
mysql -h sql211.infinityfree.com -u if0_43338625 -p if0_43338625 n7_gestao < backup.sql
```
